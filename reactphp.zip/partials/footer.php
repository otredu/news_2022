<footer class="centeredtext">Tredun datanomit ovat parhaita</footer>
</body>
</html>